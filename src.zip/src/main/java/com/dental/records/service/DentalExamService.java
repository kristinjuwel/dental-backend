package com.dental.records.service;

public class DentalExamService {

}
