package com.dental.records.model;

import java.sql.Date;

import jakarta.persistence.*;

@Entity
@Table(name = "dental_exam")
public class DentalExam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "exam_id")
    private Long examId;

    @Column(name = "patient_id")
    private Integer patientId;

    @Column(name = "dentist_id")
    private Integer dentistId;

    @Column(name = "region", length = 30)
    private String region;

    @Column(name = "purpose", nullable = false, length = 35)
    private String purpose;

    @Column(name = "purpose_date", nullable = false)
    private Date purposeDate;

    @Column(name = "calculus", length = 50)
    private String calculus;

    @Column(name = "remarks", length = 255)
    private String remarks;

    @Column(name = "chief_name", length = 255)
    private String chiefName;

    @Column(name = "chief_sign")
    private byte[] chiefSign;

    @Column(name = "dent_image", nullable = false)
    private byte[] dentImage;

    @ManyToOne
    @JoinColumn(name = "patient_id", insertable = false, updatable = false)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "dentist_id", insertable = false, updatable = false)
    private Dentist dentist;
    
    public DentalExam() {
    	
    }

	public DentalExam(Long examId, Integer patientId, Integer dentistId, String region, String purpose,
			Date purposeDate, String calculus, String remarks, String chiefName, byte[] chiefSign, byte[] dentImage,
			Patient patient, Dentist dentist) {
		super();
		this.examId = examId;
		this.patientId = patientId;
		this.dentistId = dentistId;
		this.region = region;
		this.purpose = purpose;
		this.purposeDate = purposeDate;
		this.calculus = calculus;
		this.remarks = remarks;
		this.chiefName = chiefName;
		this.chiefSign = chiefSign;
		this.dentImage = dentImage;
		this.patient = patient;
		this.dentist = dentist;
	}

	public Long getExamId() {
		return examId;
	}

	public void setExamId(Long examId) {
		this.examId = examId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getDentistId() {
		return dentistId;
	}

	public void setDentistId(Integer dentistId) {
		this.dentistId = dentistId;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public Date getPurposeDate() {
		return purposeDate;
	}

	public void setPurposeDate(Date purposeDate) {
		this.purposeDate = purposeDate;
	}

	public String getCalculus() {
		return calculus;
	}

	public void setCalculus(String calculus) {
		this.calculus = calculus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getChiefName() {
		return chiefName;
	}

	public void setChiefName(String chiefName) {
		this.chiefName = chiefName;
	}

	public byte[] getChiefSign() {
		return chiefSign;
	}

	public void setChiefSign(byte[] chiefSign) {
		this.chiefSign = chiefSign;
	}

	public byte[] getDentImage() {
		return dentImage;
	}

	public void setDentImage(byte[] dentImage) {
		this.dentImage = dentImage;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Dentist getDentist() {
		return dentist;
	}

	public void setDentist(Dentist dentist) {
		this.dentist = dentist;
	}
    
    
}