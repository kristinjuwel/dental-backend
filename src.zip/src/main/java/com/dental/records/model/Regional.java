package com.dental.records.model;

public class Regional {

}
