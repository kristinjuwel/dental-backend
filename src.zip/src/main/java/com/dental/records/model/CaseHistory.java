package com.dental.records.model;

import jakarta.persistence.*;

@Entity
@Table(name = "case_history")
public class CaseHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "case_id")
    private Long caseId;

    @Column(name = "complaint", length = 255)
    private String complaint;

    @Column(name = "med_hist", length = 255)
    private String medHist;

    @Column(name = "bp", length = 30)
    private String bp;

    @Column(name = "exam_id", nullable = false)
    private Integer examId;

    @ManyToOne
    @JoinColumn(name = "exam_id", insertable = false, updatable = false)
    private DentalExam dentalExam;
    
    public CaseHistory() {
    	
    }

	public CaseHistory(Long caseId, String complaint, String medHist, String bp, Integer examId,
			DentalExam dentalExam) {
		super();
		this.caseId = caseId;
		this.complaint = complaint;
		this.medHist = medHist;
		this.bp = bp;
		this.examId = examId;
		this.dentalExam = dentalExam;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getComplaint() {
		return complaint;
	}

	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}

	public String getMedHist() {
		return medHist;
	}

	public void setMedHist(String medHist) {
		this.medHist = medHist;
	}

	public String getBp() {
		return bp;
	}

	public void setBp(String bp) {
		this.bp = bp;
	}

	public Integer getExamId() {
		return examId;
	}

	public void setExamId(Integer examId) {
		this.examId = examId;
	}

	public DentalExam getDentalExam() {
		return dentalExam;
	}

	public void setDentalExam(DentalExam dentalExam) {
		this.dentalExam = dentalExam;
	}
    
    
}