package com.dental.records.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dental.records.model.DentalExam;

public interface DentalExamRepository extends JpaRepository<DentalExam, Long>{

}
