package com.dental.records.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dental.records.model.CaseHistory;

public interface CaseHistoryRepository extends JpaRepository<CaseHistory, Long>{

}
