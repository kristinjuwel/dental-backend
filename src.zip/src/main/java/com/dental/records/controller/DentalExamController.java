package com.dental.records.controller;

public class DentalExamController {

}
